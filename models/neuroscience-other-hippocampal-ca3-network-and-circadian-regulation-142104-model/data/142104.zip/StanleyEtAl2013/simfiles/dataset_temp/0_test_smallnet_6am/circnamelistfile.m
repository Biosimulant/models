circnamelist{1} = '0_test_smallnet_6am/t6';
