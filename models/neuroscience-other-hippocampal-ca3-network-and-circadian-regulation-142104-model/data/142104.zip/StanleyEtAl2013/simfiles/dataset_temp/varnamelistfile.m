% List of variable names
varnamelist{1} = 'test_smallnet_6am';
