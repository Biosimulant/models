% List of pathnames
fnamelist{1} = '0_test_smallnet_6am';
