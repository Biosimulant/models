% List of pathnames
fnamelist{1} = '0_test_fullnet_6am';
