% List of variable names
varnamelist{1} = 'test_fullnet_6am';
