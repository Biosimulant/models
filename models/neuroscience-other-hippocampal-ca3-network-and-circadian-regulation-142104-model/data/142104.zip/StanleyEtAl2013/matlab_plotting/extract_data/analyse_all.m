

timenum_range = [0 2 3 4 6 8 9 10 12];
for i = 1:length(timenum_range)
% for i = 6:9
    timenum0 = timenum_range(i);
    analyse_script
end