

currentfolder = pwd;
cd ('/Users/davestanley/Nex/MATLAB/Evol_mod/');

set_path_evol_mod

cd (currentfolder)
clear currentfolder;
