

currentfolder = pwd;
cd /odusers/davestanley/Documents/Matlab/Evol_mod

set_path_evol_mod

cd (currentfolder)
clear currentfolder;

