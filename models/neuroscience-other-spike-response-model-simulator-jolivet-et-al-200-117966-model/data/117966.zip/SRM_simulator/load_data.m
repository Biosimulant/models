function output = load_data()
%LOAD_DATA Summary of this function goes here
%   Detailed explanation goes here
output = load('modeldB_data.mat');