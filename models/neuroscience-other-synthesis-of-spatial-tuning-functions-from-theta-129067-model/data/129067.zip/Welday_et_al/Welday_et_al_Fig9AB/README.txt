This folder contains NEURON program files and spike data files for
reproducing the place cell simulations on a linear track in Figs. 9A
and 9B of Welday et al.  See headers of RUNSIM_FIG9A.hoc and
RUNSIM_FIG9B.hoc for further instructions.
