This folder contains MATLAB scripts for analyzing theta cell spike
train data, and a data file with raw spike data for the example
session plotted in Fig. 1 of Welday et al.  See header of
'autocorr_power.mat' for documentation of data anlysis code.
