This folder contains NEURON program files, spike data files, and
MATLAB script for reproducing the grid cell simulation in Fig. 9C of
Welday et al.  See header of GRIDCELL_SIM.hoc, PLACE_SIM.hoc, and
BOUNDARY_SIM.hoc for instructions.
