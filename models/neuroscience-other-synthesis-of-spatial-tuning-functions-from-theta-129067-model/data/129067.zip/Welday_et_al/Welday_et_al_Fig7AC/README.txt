This folder contains a MATLAB script for reproducing the analytical
envelope simulations in Fig. 7A and 7C of Welday et al.  See headers
MATLAB script files for further for documentation and instructions.
