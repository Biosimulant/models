<?php
# this is the main page for NSweep Admin
#  
#
# Bob Calin-Jageman

# should start all admin pages
require('ini.php');
header("Location: admin");
?>
nothing here