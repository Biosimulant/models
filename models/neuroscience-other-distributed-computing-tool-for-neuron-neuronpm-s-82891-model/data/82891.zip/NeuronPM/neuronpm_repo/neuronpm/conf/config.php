<?php
define("DB_HOST",'localhost');
define("DB_PORT",'3306');
define("DB_NAME",'neuronpm');
define("DB_USER",'neuronpm');
define("DB_PASS",'pword');
define("USER", 'admin');
define("PASS", 'pword');
define("APPROVEDONLY", '1');
define("CLIENTPASS", 'pword');
?>
