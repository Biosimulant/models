<?php
require_once("../client_ini.php");
if (!defined('BASE')) exit('');
require_once("../Connections/conn_nsweep.php");
echo "<nsweep>success=true</nsweep>";
?>