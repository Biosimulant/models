Public Class preview

    Private Sub preview_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Close()
    End Sub
End Class