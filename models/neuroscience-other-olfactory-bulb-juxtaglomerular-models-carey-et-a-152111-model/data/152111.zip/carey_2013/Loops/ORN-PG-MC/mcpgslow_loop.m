gain = 1;    
doloop('orn_inputs_depr', gain, @MCRI_PGslow, 'PGMCS_tc', '170')
