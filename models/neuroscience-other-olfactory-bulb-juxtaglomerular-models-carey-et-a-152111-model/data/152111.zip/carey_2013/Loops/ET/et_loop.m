function et_loop(input)
    gain = input;
    doloop('orn_inputs_depr', gain, @ET)
end