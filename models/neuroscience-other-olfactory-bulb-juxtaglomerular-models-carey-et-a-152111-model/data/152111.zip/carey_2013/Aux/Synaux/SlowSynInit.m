function A = SlowSynInit(vpre, vHalf, p)
A = zeros(2,1);