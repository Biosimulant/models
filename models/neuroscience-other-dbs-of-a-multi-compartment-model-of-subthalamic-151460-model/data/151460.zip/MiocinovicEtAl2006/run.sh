#!/bin/bash
nrngui -Py_NoSiteFlag main.hoc
