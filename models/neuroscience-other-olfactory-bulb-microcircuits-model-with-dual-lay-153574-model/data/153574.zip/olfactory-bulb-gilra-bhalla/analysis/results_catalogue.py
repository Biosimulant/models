seeds = [
("100.0","160.0"),
("100.0","190.0"),
("500.0","160.0"),
("500.0","set"),
("300.0","157.0"),
("700.0","191.0")
]
filelist = [
["2011_05_15_14_23_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_15_22_51_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_17_23_14_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_18_10_48_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_20_13_54_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_22_10_03_odormorph_NOSINGLES_NOJOINTS_NOPGS_numgloms10.pickle"],

["2011_05_15_15_54_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_16_00_24_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_19_00_22_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_20_11_49_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_20_21_01_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle",
"2011_05_22_20_14_odormorph_SINGLES_NOJOINTS_NOPGS_numgloms10.pickle"],

["2011_05_15_18_55_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle",
"2011_05_16_23_05_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle",
"2011_05_19_03_31_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle",
"2011_05_19_21_09_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle",
"2011_05_21_00_20_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle",
"2011_05_22_18_47_odormorph_SINGLES_JOINTS_NOPGS_numgloms10.pickle"],

["2011_05_15_01_07_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle",
"2011_05_15_22_30_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle",
"2011_05_17_22_51_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle",
"2011_05_18_14_51_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle",
"2011_05_20_18_46_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle",
"2011_05_22_15_24_odormorph_SINGLES_JOINTS_PGS_numgloms10.pickle"]
]
