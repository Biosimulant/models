## This file is programmatically generated.

netseedstr = "844.0"
rateseedstr = "844.0"

OBNet_file = "../netfiles/syn_conn_array_10000_singlesclubbed100_jointsclubbed1_numgloms3_seed844.0_directed0.01_proximal.xml"
ORNpathseedstr = "../firefiles/firefiles844.0/"
NO_SINGLES = False
## spine inhibition and singles are self-inh
## toggle them on/off together
NO_SPINE_INH = NO_SINGLES
NO_JOINTS = False
NO_MULTIS = NO_JOINTS
NO_PGS = False
NO_LATERAL = False

VARY_MITS_RMP = False
