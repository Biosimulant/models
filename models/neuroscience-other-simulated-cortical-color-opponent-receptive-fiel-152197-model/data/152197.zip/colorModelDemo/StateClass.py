class StateClass(object):
    def __init__(self):
        self.name = "to save network states"
        