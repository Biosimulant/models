/* $Id: spike_ext.h,v 1.1.1.1 2005/06/14 04:38:28 svitak Exp $
**
** $Log: spike_ext.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:28  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1998/03/31 22:10:24  dhb
** Initial revision
**
*/

#include "sim_ext.h"
#include "spike_struct.h"
