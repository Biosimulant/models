/*
** $Id: per_struct.h,v 1.1.1.1 2005/06/14 04:38:34 svitak Exp $
** $Log: per_struct.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:34  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1992/12/11 19:03:45  dhb
** Initial revision
**
*/

