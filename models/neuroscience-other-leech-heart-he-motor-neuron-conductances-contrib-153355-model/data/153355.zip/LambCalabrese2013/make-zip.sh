zip -r lamb-simhe-model.zip README *.par input lgenesis-noX make-zip.sh Models_SubA_SubB_C Scripts
