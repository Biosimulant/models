from white_image import *
from bar_image import *
from natural_image import *
from rotate_sphere import *
from vert_strip import *
    
