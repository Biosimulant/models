SIM_VS_NET README FILE
--------------------


Implements the model of the VS network used in the following article: 

Near optimal decoding of transient stimuli from coupled neuronal subpopulations

by James Trousdale, Sam Carroll, Fabrizio Gabbiani, and Kresimir Josic.

J. Neurosci. 34:12206-12222.

The code is written in Python (www.python.org) and was tested with
python 2.7. In addition to python, it requires the matplotlib, numpy
and scipy packages (available on the web at matplotlib.org, numpy.org
and scipy.org). Rotation of the images and generation of corresponding
mpeg movies require ffmpeg (www.ffmpeg.org).  


For a detailed description of the directory content, please read fly_code_note.pdf



