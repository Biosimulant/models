export NEST_INSTDIR="$HOME/bin/nest"
export PATH="$NEST_INSTDIR/bin:${PATH}"
export LD_LIBRARY_PATH="$NEST_INSTDIR/lib:${LD_LIBRARY_PATH}"
export SLIDATADIR=$NEST_INSTDIR/share/nest
export PYTHONPATH="$NEST_INSTDIR/lib/python2.7/site-packages/"

