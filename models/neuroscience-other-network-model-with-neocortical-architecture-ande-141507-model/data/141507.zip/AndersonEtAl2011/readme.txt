These are the files for a paper under review: and a fresh paper:

Anderson WS, Azhar F, Kudela P, Bergey GK, Franaszczuk PJ. Epileptic
seizures from abnormal networks: Why some seizures defy
predictability. Epi Res doi: 10.1016/j.eplepsyres.2011.11.006.
