#!/usr/bin/bash

Scripts/Python/generateComputationCommands \
sholl:May3h-apical / sholl:May3x-apical
