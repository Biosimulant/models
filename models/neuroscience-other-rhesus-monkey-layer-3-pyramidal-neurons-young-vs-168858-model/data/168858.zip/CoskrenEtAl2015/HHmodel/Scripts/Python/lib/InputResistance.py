#!/usr/bin/python



class InputResistance:
  """ """

  def __init__(self):
    pass
