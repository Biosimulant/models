#ifndef _modelLumpedNeuron_H_
#define _modelLumpedNeuron_H_

void modelLumpedNeuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
