#ifndef _NMDA_Synapse_H_
#define _NMDA_Synapse_H_
void modelNMDAsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
