#ifndef _modelRose_H_
#define _modelRose_H_

void modelRose(double t,double *x,double *dx,double *parameter,double *extra);

#endif
