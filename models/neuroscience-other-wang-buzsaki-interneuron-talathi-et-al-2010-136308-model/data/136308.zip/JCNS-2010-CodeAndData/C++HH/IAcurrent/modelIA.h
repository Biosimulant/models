#ifndef _IA_channel_H_
#define _IA_channel_H_
void modelIA(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
