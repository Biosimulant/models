#ifndef _modelHHneuron_H_
#define _modelHHneuron_H_

void modelHHneuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
