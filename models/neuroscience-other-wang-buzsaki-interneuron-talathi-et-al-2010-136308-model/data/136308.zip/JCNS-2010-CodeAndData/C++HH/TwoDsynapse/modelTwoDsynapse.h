#ifndef _2D_Synapse_H_
#define _2D_Synapse_H_
void modelTwoDsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
