#ifndef _modelMinneuron_H_
#define _modelMinneuron_H_

void modelMinneuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
