#ifndef _Ih_channel_H_
#define _Ih_channel_H_
void modelIh(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
