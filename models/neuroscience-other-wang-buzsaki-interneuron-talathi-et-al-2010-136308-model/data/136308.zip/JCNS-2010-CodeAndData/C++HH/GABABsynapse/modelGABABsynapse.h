#ifndef _GABAB_Synapse_H_
#define _GABAB_Synapse_H_
void modelGABABsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
