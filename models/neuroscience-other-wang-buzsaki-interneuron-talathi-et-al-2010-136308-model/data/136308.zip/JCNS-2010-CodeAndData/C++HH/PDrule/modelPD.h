#ifndef _PD_rule_H_
#define _PD_rule_H_
void modelPD(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
