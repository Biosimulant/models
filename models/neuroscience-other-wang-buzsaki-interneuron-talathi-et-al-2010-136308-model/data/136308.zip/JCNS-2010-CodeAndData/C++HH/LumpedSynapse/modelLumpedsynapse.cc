#include "modelLumpedsynapse.h"
#include "math.h"
#include <iostream.h>
#include<fstream.h>
/*
Lumped Synapse Model: It is just a sigmoid non-linearity.No differential equations*/
void
modelLumpedsynapse (double t, double *x, double *dx, double *parameter, double
		*extra)
{
  
}
