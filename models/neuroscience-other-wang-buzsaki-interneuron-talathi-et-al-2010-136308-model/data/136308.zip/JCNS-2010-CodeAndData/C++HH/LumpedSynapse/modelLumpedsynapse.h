#ifndef _Lumped_Synapse_H_
#define _Lumped_Synapse_H_
void modelLumpedsynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
