#ifndef _modelIzhineuron_H_
#define _modelIzhineuron_H_

void modelIzhineuron(double t,double *x,double *dx,double *parameter,double *extra);
#endif
