#include <math.h>
#ifndef _define_h
#define _define_h
#define gdensoma 1. 
#define gsomaden 3.5
#define gampa 1.5*1.0
#define gcampa 1.5*pow(10.,-4)*1.0
#define gnmda .05
#define gcnmda .0488*1.0
#define gt 1.0*4.5*pow(10,-7)
#define gtc 27 * pow(10.,-6.)*1.0
#define gaa 100
#define gm 6.7
#endif
