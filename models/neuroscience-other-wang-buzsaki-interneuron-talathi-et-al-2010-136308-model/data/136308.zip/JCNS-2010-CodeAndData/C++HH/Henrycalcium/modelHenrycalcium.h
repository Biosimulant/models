#ifndef _Henrycalcium_channel_H_
#define _Henrycalcium_channel_H_
void modelHenrycalcium(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
