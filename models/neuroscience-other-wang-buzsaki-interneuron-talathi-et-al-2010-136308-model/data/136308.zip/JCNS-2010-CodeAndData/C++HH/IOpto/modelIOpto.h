#ifndef _IOpto_channel_H_
#define _IOpto_channel_H_
void modelIOpto(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
