#ifndef _IM_channel_H_
#define _IM_channel_H_
void modelIM(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
