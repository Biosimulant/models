#include "modelIAHP.h"
#include "math.h"

void modelIAHP(double t,double *x,double *dx,double *parameter,double *extra)
{
double v;

v=extra[1];
}

