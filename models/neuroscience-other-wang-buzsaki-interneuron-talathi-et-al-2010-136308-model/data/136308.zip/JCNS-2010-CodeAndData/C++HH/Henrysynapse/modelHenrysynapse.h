#ifndef _Henry_Synapse_H_
#define _Henry_Synapse_H_
void modelHenrysynapse(double t,double *x,double *dx,double *parameter,double
*extra);
#endif
